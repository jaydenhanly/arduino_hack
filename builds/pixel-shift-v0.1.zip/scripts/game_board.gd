extends Node2D

const Grid = preload("res://scripts/grid.gd")
const Art = preload("res://scripts/pixel_art.gd")

var stage: RefCounted
var clock := 0.0

func _draw() -> void:
	draw_rect(Rect2(Grid.ORIGIN - Vector2(3, 3), Vector2(Grid.SIZE * Grid.CELL) + Vector2(6, 6)), Art.INK, false, 2)
	for row in Grid.SIZE.y:
		for column in Grid.SIZE.x:
			draw_rect(Rect2(Grid.ORIGIN + Vector2(column, row) * Grid.CELL + Vector2(6, 6), Vector2.ONE), Art.MID)
	if stage == null:
		return
	var snake: RefCounted = stage
	draw_rect(Grid.rect(snake.obstacle).grow(-1), Art.DARK)
	draw_rect(Grid.rect(snake.obstacle).grow(-4), Art.INK)
	Art.bitmap(self, Art.APPLE, Grid.rect(snake.apple).position + Vector2(3, 3), 1, Art.INK)
	for index in range(snake.body.size() - 1, -1, -1):
		if snake.body.size() == 1 and fmod(clock, 0.8) > 0.5:
			continue
		var cell: Vector2i = snake.body[index]
		var tile := Grid.rect(cell).grow(-1)
		if snake.stretch > 0:
			tile.position = Grid.rect(snake.body[0]).grow(-1).position.lerp(tile.position, 1.0 - snake.stretch / 0.22).round()
		draw_rect(tile, Art.INK if index == 0 else Art.DARK)
		if index == 0:
			draw_rect(Rect2(tile.position + Vector2(3, 3), Vector2(2, 2)), Art.LIGHT)
			draw_rect(Rect2(tile.position + Vector2(7, 3), Vector2(2, 2)), Art.LIGHT)
