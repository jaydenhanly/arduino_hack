extends Node2D

const Grid = preload("res://scripts/grid.gd")
const Art = preload("res://scripts/pixel_art.gd")
const SnakeStage = preload("res://scripts/snake_stage.gd")
const Board = preload("res://scripts/game_board.gd")

enum State { TITLE, PLAYING, SHIFTING, PAUSED, LIFE_LOST, GAME_OVER, VICTORY }

var state := State.TITLE
var previous_state := State.PLAYING
var current_stage := "snake"
var score := 0
var lives := 3
var active_seed := 2026
var stage: RefCounted
var board: Node2D
var clock := 0.0
var damage_reason := ""
var invulnerable := false

func _ready() -> void:
	Engine.max_fps = 60
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	Grid.install_inputs()
	board = Board.new()
	board.z_index = -1
	add_child(board)
	board.visible = false

func _unhandled_input(event: InputEvent) -> void:
	if event.is_echo():
		return
	if event.is_action_pressed("cancel"):
		state = State.TITLE
		board.visible = false
	elif event.is_action_pressed("pause"):
		if state == State.PAUSED:
			state = previous_state
		elif state in [State.PLAYING, State.SHIFTING]:
			previous_state = state
			state = State.PAUSED
	elif event.is_action_pressed("confirm"):
		if state in [State.TITLE, State.GAME_OVER, State.VICTORY]:
			start_run()
		elif state == State.LIFE_LOST:
			restart_stage()
		elif state == State.PAUSED:
			state = previous_state
	elif state == State.PLAYING:
		stage.steer(Grid.direction_for(event))
	queue_redraw()

func _process(delta: float) -> void:
	if state != State.PAUSED:
		clock += delta
		board.clock = clock
	if state == State.PLAYING:
		stage.advance(delta)
	board.queue_redraw()
	queue_redraw()

func start_run(seed_value: int = 2026) -> void:
	active_seed = seed_value
	score = 0
	lives = 3
	current_stage = "snake"
	restart_stage()

func restart_stage() -> void:
	stage = SnakeStage.new()
	stage.initialize(active_seed)
	stage.invulnerable = invulnerable
	stage.points_earned.connect(_on_points)
	stage.life_lost.connect(_on_life_lost)
	stage.objective_completed.connect(_on_objective_completed)
	board.stage = stage
	board.visible = true
	state = State.PLAYING

func _on_points(amount: int) -> void:
	score += amount

func _on_life_lost(reason: String) -> void:
	lives -= 1
	damage_reason = reason
	state = State.GAME_OVER if lives == 0 else State.LIFE_LOST

func _on_objective_completed() -> void:
	state = State.VICTORY

func _draw() -> void:
	if state == State.TITLE:
		_draw_title()
		return
	Art.text(self, "01 SNAKE", Vector2(14, 12))
	Art.text(self, "SCORE %04d" % score, Vector2(154, 12))
	for index in 3:
		Art.bitmap(self, Art.HEART, Vector2(348 + index * 13, 11), 1, Art.INK if index < lives else Art.MID)
	draw_line(Vector2(12, 28), Vector2(388, 28), Art.DARK, 2)
	Art.centered(self, "APPLES %d/5   BUTTON C PAUSE" % stage.apples, 225)
	if state == State.PLAYING and stage.direction == Vector2i.ZERO:
		Art.centered(self, "ONE PIXEL. YOUR MOVE.", 61)
		Art.centered(self, "JOYSTICK TO BEGIN", 77, 1, Art.DARK)
	elif state == State.PAUSED:
		_panel("PAUSED", "BUTTON C RESUME", "BUTTON B TITLE")
	elif state == State.LIFE_LOST:
		_panel(damage_reason, "%d LIVES LEFT" % lives, "BUTTON A RETRY")
	elif state == State.GAME_OVER:
		_panel("GAME OVER", "SCORE %04d" % score, "BUTTON A REPLAY")
	elif state == State.VICTORY:
		_panel("SNAKE COMPLETE", "SCORE %04d" % score, "BUTTON A REPLAY")

func _panel(title: String, line_one: String, line_two: String, top: int = 85, height: int = 78) -> void:
	draw_rect(Rect2(42, top + 4, 320, height), Art.INK)
	draw_rect(Rect2(38, top, 320, height), Art.LIGHT)
	draw_rect(Rect2(38, top, 320, height), Art.INK, false, 2)
	Art.centered(self, title, top + 11, 2 if title.length() < 20 else 1)
	Art.centered(self, line_one, top + 36)
	Art.centered(self, line_two, top + height - 15)

func _draw_title() -> void:
	draw_rect(Rect2(12, 12, 376, 216), Art.INK, false, 2)
	Art.text(self, "RETRO-AI / ONE CONTINUOUS GAME", Vector2(24, 24), 1, Art.DARK)
	Art.centered(self, "PIXEL", 48, 4)
	Art.centered(self, "SHIFT", 83, 4)
	for index in 7:
		var position_value := Vector2(123 + index * 20, 127 + (8 if index > 3 else 0))
		draw_rect(Rect2(position_value, Vector2(16, 16)), Art.INK if index == 0 else Art.DARK)
		if index == 0:
			draw_rect(Rect2(position_value + Vector2(3, 3), Vector2(3, 3)), Art.LIGHT)
	Art.centered(self, "A LITTLE SNAKE. A BIG CHANGE.", 157)
	if fmod(clock, 1.1) < 0.85:
		Art.centered(self, "BUTTON A START", 181, 2)
	Art.centered(self, "JOYSTICK MOVE  /  BUTTON C PAUSE", 211, 1, Art.DARK)
